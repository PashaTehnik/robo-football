import cv2
import numpy as np

def rotate_image(img, angle=0):
    w = 640
    h = 480
    center = (w / 2, h / 2)
    matrix = cv2.getRotationMatrix2D(center, angle, 1.0)
    rotated_img = cv2.warpAffine(img, matrix, (w, h), flags=cv2.INTER_LINEAR)
    return rotated_img

h1 = 118
s1 = 39
v1 = 97

h2 = 135
s2 = 71
v2 = 140

h_min = np.array((h1, s1, v1), np.uint8)
h_max = np.array((h2, s2, v2), np.uint8)

cam = cv2.VideoCapture("nvarguscamerasrc ! video/x-raw(memory:NVMM), width=(int)640, height=(int)480, format=(string)NV12, framerate=(fraction)30/1 ! nvvidconv ! video/x-raw, format=(string)BGRx ! videoconvert ! video/x-raw, format=(string)BGR ! appsink")


area = 0
area1 = 0
bigarea = 0

while 1:
	ret, unrotate_img = cam.read()
	img = rotate_image(unrotate_img, 180)	
	hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV )
	thresh = cv2.inRange(hsv, h_min, h_max)
	
	contours, hierarchy = cv2.findContours(thresh.copy(), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
	
	cv2.drawContours( thresh, contours, -1, (255,0,0), 3, cv2.LINE_AA, hierarchy, 1 )
	for cnt in contours:
		if len(cnt)>60:#60
			rect = cv2.minAreaRect(cnt) # пытаемся вписать прямоугольник
			box = cv2.boxPoints(rect) # поиск четырех вершин прямоугольника
			box = np.int0(box) # округление координат
			area1 = area
			area = int(rect[1][0]*rect[1][1])
			if area > area1:
				bigarea = area
				bigbox = box 
			else:
				bigarea = area1
				bigbox = box
			
			print (bigbox)
			np.savetxt('t.txt', bigbox)
			
			cv2.drawContours(img,[box],0,(255,0,0),2) # рисуем прямоугольник
	
	cv2.imshow('huyna yebanaya, idi nahuy', img)
	
	k = cv2.waitKey(5) & 0xff
	if k == 27:
		break
	
capture.release()
cv2.destroyAllWindows()

