//gcc -o test  WiringTest.cpp -lwiringPi -lwiringPiDev -lpthread -lm -lcrypt -lrt


#include <stdio.h>
#include <wiringSerial.h>
char buff[3];
int fd;

int main(){
buff[1] = 1;
buff[2] = 2;
buff[3] = 7;
while(1){
fd = serialOpen("/dev/ttyUSB0", 9600);
serialPutchar(3, buff[1]);
serialClose(3);
}	
}

/*#include <iostream>
#include <stdio.h>
using namespace std;

int
main()
{
  FILE *file;
  //Opening device file

  int getnum = 127;

  while (true)
    {
      file = fopen("/dev/ttyUSB0", "w");
      fprintf(file, "%d", getnum); //Writing to the file
      fclose(file);
    }

}*/
