//gcc -O3 -o test2 -Wall -I/usr/local/include -Winline -pipe -L/usr/local/lib test2.cpp  -lwiringPi -lwiringPiDev -lpthread -lm -lcrypt -lrt
//
//
// otpravit' govno na arduino
//
// 1 byte - leftmotor , 2 bit - rightmotor, 3 bit - srakamotor
//
// 1 bit - napravlenie(1 - vpravo)
// ostalnie - power 0-100
// 
//
#include <stdio.h>
#include <wiringSerial.h>
#include <sys/mman.h>
#include <time.h>
#include <csignal>
#include <string.h>  /* Объявления строковых функций */
#include <unistd.h>  /* Объявления стандартных функций UNIX */
#include <errno.h>   /* Объявления кодов ошибок */
#include "termios.h" /* Объявления управления POSIX-терминалом */
 






 
int open_port(void);      //Функция открытия порта
 
/*
int gg(int argc,char **argv)
{
int k;
int fd=open_port();
int n;
n = write(fd, "g", 1);
if (n < 0)
{
  fputs("write() of 4 bytes failed!\n", stderr);
}
else
 
{
printf(" n= %d  \n",n)  ;
}
 
close(fd);
return(0);
}
/* 
  int  open_port(void)
    {
      int fd;
   fd = open("/dev/ttyS0", O_RDWR | O_NOCTTY |O_NONBLOCK);
  if (fd == -1)
  {
   / *
    * Could not open the port.
    * /
 
   perror("open_port: Unable to open /dev/ttyS0 - "); 
  }
   else
      fcntl(fd, F_SETFL, 0);
   return (fd);
    }

*/










FILE *f;
int height = 480,
    width = 640;

char ggwp[3];
int pwr = 50;//max 127

void delay(int number_of_seconds) 
{ 
    // Converting time into milli_seconds 
    
  
    // Storing start time 
    clock_t start_time = clock(); 
  
    // looping till required time is not achieved 
    while (clock() < start_time + number_of_seconds); 

} 
float m[8];
float b[2];

int goal;
/////////////////////////////////

void toArduino(int nap, int pwr){
int fd = open("/dev/ttyUSB0",O_RDWR, S_IWRITE); /*'open_port()' - Открывает последовательный порт */
  if (fd == -1)
        {
          /*
           * Возвращает файловый дескриптор при успехе или -1 при ошибке.
           */
           printf("error port\n");
           perror("open_port: Unable to open /dev/ttyUSBn - ");
        }
     else
        {
         struct termios options; /*структура для установки порта*/
         tcgetattr(fd, &options); /*читает пораметры порта*/
        
         cfsetispeed(&options, B115200); /*установка скорости порта*/
         
        // options.c_cflag &= ~PARENB; /*выкл проверка четности*/
         //options.c_cflag &= ~CSTOPB; /*выкл 2-х стобит, вкл 1 стопбит*/
         options.c_cflag &= ~CSIZE; /*выкл битовой маски*/
         options.c_cflag |= CS8; /*вкл 8бит*/
         tcsetattr(fd, TCSANOW, &options); /*сохронения параметров порта*/
        
        }

int n;
n = write(fd, "g", 1);
close(fd);


/*
serialOpen("/dev/ttyUSB0",115200);
serialPutchar(3, pwr);
serialPutchar(3, (1<<7)|nap);
serialClose(6);
//printf("%d\n", nap);
delay(100);

*/
}




int exit = 0;
////		M	//////	A	///////		I	///////		N	////////////////////

void signalHandler(int signum){
//printf("\n%d\n\n", signum);
if(signum == 2) exit = 2;
serialOpen("/dev/ttyUSB0",115200);
serialPutchar(3, 0);
serialPutchar(3, 0);
serialClose(6);
printf("\n\n\nbye bye\n");
}

int main(){
int widthd2 = (int)(width/2);
while(exit==0){
	//serialOpen("/dev/ttyUSB0",9600);

	f = fopen("t.txt", "r");
	fscanf(f,"%f %f \n %f %f \n %f %f \n %f %f",&m[0], &m[1],&m[2],&m[3],&m[4],&m[5],&m[6],&m[7]);
	//printf ("%d %d \n%d %d \n%d %d \n%d %d \n\n\n", int(m[0]), int(m[1]), int(m[2]), int(m[3]), int(m[4]), int(m[5]), int(m[6]), int(m[7]));
	fclose(f);
	f = fopen("b.txt", "r");
	fscanf(f,"(%f, %f ",&b[0], &b[1]);
	//printf ("%d %d \n\n\n\n", int(b[0]), int(b[1]));
	fclose(f);


	if(b[0]>widthd2 + 10) toArduino(1, pwr);
	if(b[0]<widthd2 - 10) toArduino(2, pwr);
	if ((b[0]>=widthd2 - 10)&&(b[0]<=widthd2 + 10)){
		
		goal = int ((m[2] + m[6])/2);
	if(goal>widthd2 + 10) toArduino(4, pwr);
	if(goal<widthd2 - 10) toArduino(3, pwr);
	if ((goal>=widthd2 - 10)&&(goal<=widthd2 + 10)) toArduino(5,100);
	}
	
	signal(SIGINT, signalHandler);
	
	
	
	
	
}

return 0;
}
