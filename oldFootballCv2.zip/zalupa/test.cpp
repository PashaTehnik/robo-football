//gcc -O3 -Wall -I/usr/local/include -Winline -pipe -L/usr/local/lib temperature.c  -lwiringPi -lwiringPiDev -lpthread -lm -lcrypt -lrt
//
//
// otpravit' govno na arduino
//
// 1 byte - leftmotor , 2 bit - rightmotor, 3 bit - srakamotor
//
// 1 bit - napravlenie(1 - vpravo)
// ostalnie - power 0-100
// 
//
#include <stdio.h>
#include <wiringSerial.h>
#include <sys/mman.h>
FILE *f;
int height = 480,
    width = 640;

char ggwp[3];
int pwr = 127;

float m[8];
float b[2];

int goal;

void toArduino(int nap, int pwr){

int* govno;
char hueta[3] = {1,2,3};
switch (nap){
case 1:
govno = ((((((((((1<<7)|(pwr))<<1)|1)<<7)|pwr)<<1)|1)<<7)|pwr);
hueta[0] = (int)((1<<7)|(pwr));
hueta[1] = (int)((1<<7)|(pwr));
hueta[2] = (int)((1<<7)|(pwr));

printf("crug pravo \n %d \n\n", govno);
//delay(1000);
break;

case 2:
govno = ((((((((((0<<7)|(pwr))<<1)|0)<<7)|pwr)<<1)|0)<<7)|pwr);
hueta[0] = (int)((0<<7)|(pwr));
hueta[1] = (int)((0<<7)|(pwr));
hueta[2] = (int)((0<<7)|(pwr));
printf("crug levo \n");
break;

case 3:
govno = ((((((((((1<<7)|(pwr/2))<<1)|1)<<7)|(pwr/2))<<1)|0)<<7)|pwr);
printf("vpravo \n");
break;

case 4:

govno = ((((((((((0<<7)|(pwr/2))<<1)|0)<<7)|(pwr/2))<<1)|1)<<7)|pwr);
printf("vlevo \n");
break;

case 5:

govno = ((((((((((1<<7)|(pwr/2))<<1)|0)<<7)|(pwr/2))<<1)|0)<<7)|0);
printf("vpered \n");
break;

govno = ((((((((((0<<7)|(pwr/2))<<1)|1)<<7)|(pwr/2))<<1)|0)<<7)|0);
case 6:
printf("nazad \n");
break;
}

serialPrintf(3, govno);

}
int main(){
serialOpen("/dev/ttyUSB4",9600);
int widthd2 = (int)(width/2);
while(1){
	f = fopen("t.txt", "r");
	fscanf(f,"%f %f \n %f %f \n %f %f \n %f %f",&m[0], &m[1],&m[2],&m[3],&m[4],&m[5],&m[6],&m[7]);
	//printf ("%d %d \n%d %d \n%d %d \n%d %d \n\n\n", int(m[0]), int(m[1]), int(m[2]), int(m[3]), int(m[4]), int(m[5]), int(m[6]), int(m[7]));
	fclose(f);
	f = fopen("b.txt", "r");
	fscanf(f,"(%f, %f ",&b[0], &b[1]);
	//printf ("%d %d \n\n\n\n", int(b[0]), int(b[1]));
	fclose(f);


	if(b[0]>widthd2 + 10) toArduino(1, pwr);
	if(b[0]<widthd2 - 10) toArduino(2, pwr);
	if ((b[0]>=widthd2 - 10)&&(b[0]<=widthd2 + 10)){
		
		goal = int ((m[2] + m[6])/2);
	if(goal>widthd2 + 10) toArduino(4, pwr);
	if(goal<widthd2 - 10) toArduino(3, pwr);
	if ((goal>=widthd2 - 10)&&(goal<=widthd2 + 10)) toArduino(5,100);
	}
	
	
	
	
	
	
	
}
return 0;
}
