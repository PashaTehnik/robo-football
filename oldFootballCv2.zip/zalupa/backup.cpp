//gcc -O3 -o test2 -Wall -I/usr/local/include -Winline -pipe -L/usr/local/lib test2.cpp  -lwiringPi -lwiringPiDev -lpthread -lm -lcrypt -lrt
//
//
// otpravit' govno na arduino
//
// 1 byte - leftmotor , 2 bit - rightmotor, 3 bit - srakamotor
//
// 1 bit - napravlenie(1 - vpravo)
// ostalnie - power 0-100
// 
//
#include <stdio.h>
#include <wiringSerial.h>
#include <sys/mman.h>
#include <time.h>
#include <csignal>
#include <string.h>  /* Объявления строковых функций */
#include <unistd.h>  /* Объявления стандартных функций UNIX */
#include <errno.h>   /* Объявления кодов ошибок */
#include "termios.h" /* Объявления управления POSIX-терминалом */
 

unsigned char buff[1] = {};

int F_ID;
FILE *f, *shit;
int height = 480,
    width = 640;

char ggwp[3];
int pwr = 50;//max 127

void delay(int number_of_seconds) 
{ 
    // Converting time into milli_seconds 
    
  
    // Storing start time 
    clock_t start_time = clock(); 
  
    // looping till required time is not achieved 
    while (clock() < start_time + number_of_seconds); 

} 
float m[8];
float b[2];

int goal;

int sendData(unsigned char* buff, int len)
{
	int n = write(F_ID, buff, len);
	if(n == -1)
	{
		char *errmsg = strerror(errno);
		//printf("%s\n", errmsg);
	}
	return n;
}



int  openPort(const char *COM_name, speed_t speed)
{
	F_ID = open(COM_name, O_RDWR | O_NOCTTY);
	if (F_ID == -1)
	{
		char *errmsg = strerror(errno);
		//printf("%s\n", errmsg);
		return 0;
	}
	struct termios options;
	tcgetattr(F_ID, &options);
	cfsetispeed(&options, speed);
	cfsetospeed(&options, speed);
	options.c_cc[VTIME] = 20;
	options.c_cc[VMIN] = 0;
	options.c_cflag &= ~PARENB;
	options.c_cflag &= ~CSTOPB;
	options.c_cflag |= CS8;
	options.c_lflag = 0;
	options.c_oflag &= ~OPOST;
	tcsetattr(F_ID, TCSANOW, &options);
return 1;
}


void closeCom(void)
{
	close(F_ID);
	F_ID = -1;
	return;
}



/////////////////////////////////

void toArduino(int nap, int pwr){

serialOpen("/dev/ttyUSB0",115200);
serialPutchar(3, pwr);
serialPutchar(3, (1<<7)|nap);
serialClose(6);
//printf("%d\n", nap);
delay(100);
}




int exit = 0;
////		M	//////	A	///////		I	///////		N	////////////////////

void signalHandler(int signum){
//printf("\n%d\n\n", signum);
if(signum == 2) exit = 2;
//serialOpen("/dev/ttyUSB0",115200);
serialPutchar(3, 0);
serialPutchar(3, 0);
serialClose(6);
printf("\n\n\nbye bye\n");
}



int main(){
int widthd2 = (int)(width/2);



while(exit==0){
	//serialOpen("/dev/ttyUSB0",9600);
//	sendData(buff,1);
	f = fopen("t.txt", "r");
	fscanf(f,"%f %f \n %f %f \n %f %f \n %f %f",&m[0], &m[1],&m[2],&m[3],&m[4],&m[5],&m[6],&m[7]);
	//printf ("%d %d \n%d %d \n%d %d \n%d %d \n\n\n", int(m[0]), int(m[1]), int(m[2]), int(m[3]), int(m[4]), int(m[5]), int(m[6]), int(m[7]));
	fclose(f);
	f = fopen("b.txt", "r");
	fscanf(f,"(%f, %f ",&b[0], &b[1]);
	//printf ("%d %d \n\n\n\n", int(b[0]), int(b[1]));
	fclose(f);


	//if(b[0]>widthd2 + 10) toArduino(1, pwr);
	//if(b[0]<widthd2 - 10) toArduino(2, pwr);
	//if ((b[0]>=widthd2 - 10)&&(b[0]<=widthd2 + 10)){
		
	//	goal = int ((m[2] + m[6])/2);
	//if(goal>widthd2 + 10) toArduino(4, pwr);
	//if(goal<widthd2 - 10) toArduino(3, pwr);
	//if ((goal>=widthd2 - 10)&&(goal<=widthd2 + 10)) toArduino(5,100);
	//}
	
	//signal(SIGINT, signalHandler);
	
	
	
	
	
}

return 0;
}
