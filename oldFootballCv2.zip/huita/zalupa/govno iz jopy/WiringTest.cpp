//gcc -o test  WiringTest.cpp -lwiringPi 


#include <stdio.h>
#include <wiringSerial.h>
//#include <dos.h>
#include <time.h>

#include <csignal>
char zalupa;
char buff[3];
int fd;


int pwr = 50;//max 127

int height = 480,
    width = 640;
int goal,exit = 0;

FILE *f;

float m[8];
float b[2];
void delay(int number_of_seconds)
{
// Storing start time
clock_t start_time = clock();

// looping till required time is not achieved

while (clock() < start_time + number_of_seconds);

}

void toArduino(int nap, int pwr){

		fd = serialOpen("/dev/ttyUSB0", 9600);
		serialPrintf (fd,"%c",pwr);
		delay(10);
		serialClose(fd);

		fd = serialOpen("/dev/ttyUSB0", 9600);
		serialPrintf (fd,"%c",(1<<7)|nap);
		delay(10);
		serialClose(fd);
		/*
			chtenie
		fd = serialOpen("/dev/ttyUSB0", 9600);
		if(0 < serialDataAvail(fd)){		
		printf("aaaa = %c\n", serialGetchar (fd));
		serialClose(fd);
		delay(10);

		*/

		printf("nap = %d, pwr = %d",nap,pwr);

}

void signalHandler(int signum){
if(signum == 2) exit = 2;
		fd = serialOpen("/dev/ttyUSB0", 9600);
		serialPrintf (fd,"%c",0);
		delay(10);
		serialClose(fd);
		delay(10);
		fd = serialOpen("/dev/ttyUSB0", 9600);
		serialPrintf (fd,"%c",(1<<7)|0);
		delay(10);
		serialClose(fd);
		printf("\n\n\nbye bye\n");
}


int main(){
int widthd2 = (int)(width/2);
while(exit==0){
	f = fopen("t.txt", "r");
	fscanf(f,"%f %f \n %f %f \n %f %f \n %f %f",&m[0], &m[1],&m[2],&m[3],&m[4],&m[5],&m[6],&m[7]);
	fclose(f);
	
f = fopen("b.txt", "r");
	fscanf(f,"(%f, %f ",&b[0], &b[1]);
	fclose(f);


	if(b[0]>widthd2 + 10) toArduino(1, pwr);
	if(b[0]<widthd2 - 10) toArduino(2, pwr);
	if ((b[0]>=widthd2 - 10)&&(b[0]<=widthd2 + 10)){
		
		goal = int ((m[2] + m[6])/2);
	if(goal>widthd2 + 10) toArduino(4, pwr);
	if(goal<widthd2 - 10) toArduino(3, pwr);
	if ((goal>=widthd2 - 10)&&(goal<=widthd2 + 10)) toArduino(5,100);
	}
	
	signal(SIGINT, signalHandler);
	
	
	
}

return 0;
}
