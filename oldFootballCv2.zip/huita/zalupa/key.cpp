//gcc -o c proga.cpp -lwiringPi -lwiringPiDev -lrt -lcrypt -lpthread -lm


#include <string.h>

#include <stdio.h>
#include <wiringSerial.h>
//#include <dos.h>
#include <time.h>
#include <csignal>
char zalupa;
char buff[3];
int fd;


int pwr = 50;//max 127

int height = 480,
    width = 640;
int goal,exit = 0;

FILE *f;

float m[8];
float b[2];
void delay(int number_of_seconds)
{
// Storing start time
clock_t start_time = clock();

// looping till required time is not achieved

while (clock() < start_time + number_of_seconds);

}
const char ggg[13]="/dev/ttyUSB0";
//string str = "";
void toArduino(int nap, int pwr){

		fd = serialOpen(ggg, 9600);
		serialPrintf (fd,"%c",pwr);
		delay(10);
		serialClose(fd);

		
		/*
			chtenie*/
		fd = serialOpen(ggg, 9600);
		if(0 < serialDataAvail(fd)){		
		printf("aaaa = %d\n", (int)serialGetchar (fd));
		serialClose(fd);
		delay(10);
}
		fd = serialOpen(ggg, 9600);
		serialPrintf (fd,"%c",(1<<7)|nap);
		delay(10);
		serialClose(fd);

		fd = serialOpen(ggg, 9600);
		if(0 < serialDataAvail(fd)){
		
		printf("bbbb = %d\n", (int)serialGetchar (fd));
		serialClose(fd);
		delay(10);
}
		

		//printf("nap = %d, pwr = %d \n",nap,pwr);
		delay(100);
}

void signalHandler(int signum){
//if(signum == 2) 
		exit = 2;
		fd = serialOpen(ggg, 9600);
		serialPrintf (fd,"%c",0);
		delay(10);
		serialClose(fd);
		delay(10);
		fd = serialOpen(ggg, 9600);
		serialPrintf (fd,"%c",(1<<7)|0);
		delay(10);
		serialClose(fd);
		printf("\n\n\nbye bye\n");
}


int main(){
int widthd2 = (int)(width/2);
int k, nap=0;//pwr = 100;
while(exit==0){
	scanf("%d",&k);		
	if(k>9) {pwr = k; printf("\npwr = %d\n\n",pwr);}
		else
		{
		nap = k;
		if (k==5){toArduino(0,pwr);printf("\nnap = 0\n\n");}
		if (k==8){toArduino(5,pwr);printf("\nnap = 5\n\n");}
		if (k==2){toArduino(6,pwr);printf("\nnap = 6\n\n");}
		if (k==4){toArduino(4,pwr);printf("\nnap = 4\n\n");}
		if (k==6){toArduino(3,pwr);printf("\nnap = 3\n\n");}
		if (k==7){toArduino(2,pwr);printf("\nnap = 2\n\n");}
		if (k==9){toArduino(1,pwr);printf("\nnap = 1\n\n");}
				
}
	
	
	signal(SIGINT, signalHandler);
}

return 0;
}
