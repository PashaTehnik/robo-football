//gcc -o c proga.cpp -lwiringPi -lwiringPiDev -lrt -lcrypt -lpthread -lm


#include <stdio.h>
#include <wiringSerial.h>
//#include <dos.h>
#include <time.h>

#include <csignal>
char zalupa;
char buff[3];
int fd;
int sens = 0;
int lf=0,rf=0,rb=0,lb=0;
int lastnap;

int height = 480,
    width = 640;
int goal,exit = 0;

FILE *f;

float m[8];
float b[2];
void delay(int number_of_seconds)
{
// Storing start time
clock_t start_time = clock();

// looping till required time is not achieved

while (clock() < start_time + number_of_seconds);

}
const char ggg[13]="/dev/ttyUSB0";
const char ddd[13]="/dev/ttyUSB1";
void toArduino(int nap, int pwr){
		lastnap = nap;
		fd = serialOpen(ggg, 9600);
		serialPrintf (fd,"%c",pwr);
		delay(10);
		serialClose(fd);

		
		/*
			chtenie*/
		fd = serialOpen(ggg, 9600);
		if(0 < serialDataAvail(fd)){		
		//printf("aaaa = %d\n", (int)serialGetchar (fd));
		serialClose(fd);
		delay(10);
}
		fd = serialOpen(ggg, 9600);
		serialPrintf (fd,"%c",(1<<7)|nap);
		delay(10);
		serialClose(fd);

		fd = serialOpen(ggg, 9600);
		if(0 < serialDataAvail(fd)){		
		//printf("bbbb = %d\n", (int)serialGetchar (fd));
		serialClose(fd);
		delay(10);
}/*
		fd = serialOpen(ddd, 9600);
		if(0 < serialDataAvail(fd)){		
		sens = (int)serialGetchar (fd);
		lf=(sens&192)>>6; rf=(sens&48)>>4; rb=(sens&12)>>2,lb=sens&3;
		serialClose(fd);
		delay(10);
}
		*/

		printf("nap = %d, pwr = %d \n",nap,pwr);
		delay(50);
}

void signalHandler(int signum){
//if(signum == 2) 
		exit = 2;
		fd = serialOpen(ggg, 9600);
		serialPrintf (fd,"%c",0);
		delay(10);
		serialClose(fd);
		delay(10);
		fd = serialOpen(ggg, 9600);
		serialPrintf (fd,"%c",(1<<7)|0);
		delay(10);
		serialClose(fd);
		printf("\n\n\nbye bye\n");
}


int pwr = 120;//max 127

int main(){
int widthd2 = (int)(width/2);
while(exit==0){
		if(sens==0){	
			f = fopen("t.txt", "r");
			fscanf(f,"%f %f \n %f %f \n %f %f \n %f %f",&m[0], &m[1],&m[2],&m[3],&m[4],&m[5],&m[6],&m[7]);
			fclose(f);
			
			f = fopen("b.txt", "r");
			fscanf(f,"(%f, %f ",&b[0], &b[1]);
			fclose(f);
			printf("\n\n m[0] = %0.1lf;	m[6] = %0.1lf;  \n\n\n\n", m[0],m[6]);

			if(b[0]>widthd2 + 100) toArduino(1, pwr);
			if(b[0]<widthd2 - 100) toArduino(2, pwr);
			if ((b[0]>=widthd2 - 150)&&(b[0]<=widthd2 + 150)){
				//toArduino(5, 115);
				goal = int ((m[2] + m[6])/2);
			if(m[6]<widthd2) toArduino(3, pwr);
			if(m[0]>widthd2) toArduino(4, pwr);
			if ((m[0]<widthd2)&&(m[6]>widthd2)) toArduino(5,127);
			}
		}
		else{
	printf("LINE\n");
			f = fopen("t.txt", "r");
			fscanf(f,"%f %f \n %f %f \n %f %f \n %f %f",&m[0], &m[1],&m[2],&m[3],&m[4],&m[5],&m[6],&m[7]);
			fclose(f);
			
			f = fopen("b.txt", "r");
			fscanf(f,"(%f, %f ",&b[0], &b[1]);
			fclose(f);
			printf("\n\n m[0] = %0.1lf;	m[6] = %0.1lf;  \n\n\n\n", m[0],m[6]);


	if((lf==1)&&(rf==1)) toArduino(6,127);
	else if((lb==1)&&(rb==1)) toArduino(5,127);
	else if((rf==1)&&(rb==1)) toArduino(4,pwr);
	else if((lf==1)&&(lb==1)) toArduino(3,pwr);
	else if(lf==1){
		toArduino(3,pwr);
		delay(150);
		toArduino(6,pwr);
		delay(150);
		}
		else if(rf==1){
			toArduino(4,pwr);
			delay(150);
			toArduino(6,pwr);
			delay(150);
			}
			else if(lb==1){
				toArduino(3,pwr);
				delay(150);
				toArduino(5,pwr);
				delay(150);
			}
			else if(rb==1){
				toArduino(4,pwr);
				delay(150);
				toArduino(6,pwr);
				delay(150);
			}
	
	}


	signal(SIGINT, signalHandler);
}

return 0;
}
